---
name: Academic AI Messenger
colors:
  surface: '#f8f9ff'
  surface-dim: '#d8dae1'
  surface-bright: '#f8f9ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f2f3fa'
  surface-container: '#ecedf5'
  surface-container-high: '#e6e8ef'
  surface-container-highest: '#e1e2e9'
  on-surface: '#191c21'
  on-surface-variant: '#444651'
  inverse-surface: '#2e3036'
  inverse-on-surface: '#eff0f7'
  outline: '#747682'
  outline-variant: '#c4c6d3'
  surface-tint: '#3f5ba6'
  primary: '#001b53'
  on-primary: '#ffffff'
  primary-container: '#0b2f7a'
  on-primary-container: '#809aeb'
  inverse-primary: '#b4c5ff'
  secondary: '#4f606e'
  on-secondary: '#ffffff'
  secondary-container: '#d3e5f6'
  on-secondary-container: '#556675'
  tertiary: '#321720'
  on-tertiary: '#ffffff'
  tertiary-container: '#4a2c35'
  on-tertiary-container: '#bc939d'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#dbe1ff'
  primary-fixed-dim: '#b4c5ff'
  on-primary-fixed: '#00174b'
  on-primary-fixed-variant: '#25428d'
  secondary-fixed: '#d3e5f6'
  secondary-fixed-dim: '#b7c9d9'
  on-secondary-fixed: '#0c1d29'
  on-secondary-fixed-variant: '#384956'
  tertiary-fixed: '#ffd9e2'
  tertiary-fixed-dim: '#e7bbc6'
  on-tertiary-fixed: '#2d141c'
  on-tertiary-fixed-variant: '#5e3e47'
  background: '#f8f9ff'
  on-background: '#191c21'
  surface-variant: '#e1e2e9'
typography:
  headline-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
    letterSpacing: -0.02em
  headline-lg-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 26px
    fontWeight: '700'
    lineHeight: 34px
    letterSpacing: -0.02em
  headline-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 22px
    fontWeight: '600'
    lineHeight: 28px
    letterSpacing: -0.015em
  headline-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 24px
    letterSpacing: -0.01em
  body-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
    letterSpacing: -0.01em
  body-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 21px
    letterSpacing: -0.005em
  body-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 13px
    fontWeight: '400'
    lineHeight: 18px
  label-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 18px
    letterSpacing: 0.01em
  label-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.02em
  label-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 11px
    fontWeight: '500'
    lineHeight: 14px
    letterSpacing: 0.02em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1rem
  gutter-mobile: 0.75rem
  margin: 1.5rem
  margin-mobile: 1rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2rem
---

## Brand & Style

This design system embodies an encouraging, disciplined, and warm academic companion for collegiate life. The identity bridges institutional authority with gentle student approachability. It operates through soft, elevated card interfaces, tactile pill shapes, and a breezy, open atmosphere reminiscent of crisp campus mornings. 

The aesthetic is Modern Soft-Tactile: clean editorial layout mechanics softened by rounded surfaces, luminous sky-tinted canvas backdrops, and friendly pastel task-tagging. The emotional posture is supportive, orderly, and bright—eradicating academic anxiety while preserving structured productivity.

## Colors

The palette establishes clarity and warmth through deliberate collegiate contrast:

- **Primary Navy (`#0B2F7A`):** Anchors institutional gravitas, primary action buttons, focused tab bars, user chat bubbles, and critical data hierarchies.
- **Secondary Sky Canvas (`#DCEEFF`):** Forms the foundational environment, establishing an airy, stress-free canvas that frames white interactive surfaces.
- **Surface Pure White (`#FFFFFF`):** Reserved for conversation cards, schedule blocks, modal sheets, and the AI agent's chat bubbles to ensure peak legible contrast.
- **Pastel Accents:**
  - **Pastel Pink (`#FFD1DC`):** Used for urgent deadlines, assignments, and exam milestone tags.
  - **Pastel Mint (`#C1F0DC`):** Applied to completed items, free study slots, and verified sync indicators.
  - **Pastel Yellow (`#FFF2B2`):** Highlights lectures, reminders, and contextual bot suggestion chips.
- **Neutral Dark (`#191C21`):** High-legibility typographic base for primary text, paired with balanced mid-tone navy-grays for secondary metadata.

## Typography

The typography utilizes Plus Jakarta Sans paired with native Korean fallbacks (Pretendard, Apple SD Gothic Neo, Noto Sans KR) to balance global geometric charm with seamless CJK readability. 

- Headings use tightened tracking (`-0.02em`) to maintain a clean, compact app presence.
- Body text employs generous vertical line-heights (`1.5` ratio) to support rapid scanning of multi-sentence AI responses and timetable summaries.
- Labels favor slightly expanded tracking to keep pill chips, timestamps, and status badges legible against soft pastel backgrounds.

## Layout & Spacing

The layout is built for fluid mobile-first messenger interaction with a centered single-column chat frame transitioning into a structured master-detail schedule split on desktop screens:

- **Mobile (< 768px):** Fluid vertical flow with `margin-mobile: 1rem` and internal component padding of `space-md`. Bottom action input floats above system home bars.
- **Tablet / Desktop (≥ 768px):** Fixed-width dual columns—left column houses conversation streams (max 480px width), right column hosts interactive weekly calendar panels and schedule agendas.
- **Vertical Rhythm:** 8px base rhythm (`0.5rem` steps) drives all gap tokens, keeping spacing between chat bursts tight (`space-xs` to `space-sm`) and card groups distinct (`space-lg`).

## Elevation & Depth

Visual depth is achieved through ambient, navy-tinted drop shadows and layered pastel planes rather than harsh borders:

- **Layer 0 (Canvas):** Pure `#DCEEFF` creates a restful, low-glare sky foundation.
- **Layer 1 (Cards & Feed Panels):** Surface `#FFFFFF` elevated with a soft tinted shadow: `0px 4px 16px rgba(11, 47, 122, 0.06)`.
- **Layer 2 (Floating Action Inputs & Drawers):** `#FFFFFF` paired with `0px 8px 24px rgba(11, 47, 122, 0.10)`.
- **Chat Elevation:**
  - AI Assistant Bubbles: Solid `#FFFFFF`, subtle outline `1px solid rgba(11, 47, 122, 0.04)`.
  - Student Bubbles: Deep Navy `#0B2F7A` with white typography, zero shadow to emphasize primary input prominence.

## Shapes

The interface balances soft friendliness with structured clarity:

- **Structured Panels & Cards:** Styled with `1rem` (16px) corner radiuses to cleanly encapsulate multi-row schedules and course details.
- **Chat Bubbles & Micro-Elements:** User and assistant chat messages transition into full pills (`9999px`) on single-line utterances, while multi-line messages maintain a 16px radius with directional rounding (e.g., 4px on bottom-right for user messages, 4px on top-left for AI messages).
- **Controls & Form Elements:** Chips, search fields, pill action buttons, and suggestion prompts adhere to fully rounded pill profiles.

## Components

- **Buttons:**
  - *Primary:* Navy `#0B2F7A` fill, white bold text, pill-shaped (`rounded-full`), padded `12px 24px`.
  - *Secondary / Suggestion:* Pastel Sky `#FFFFFF` with navy border tint `rgba(11, 47, 122, 0.12)`, navy text.
  - *Ghost:* Transparent fill, navy text, hover state using `rgba(220, 238, 255, 0.5)`.
- **Chat Bubbles:**
  - *User Bubble:* Solid `#0B2F7A`, text `#FFFFFF`, right-aligned, pill or 16px soft-cornered.
  - *AI Assistant Bubble:* Solid `#FFFFFF`, text `#191C21`, left-aligned, accompanied by circular mascot avatar, subtle boundary `1px solid rgba(11, 47, 122, 0.05)`.
- **Schedule Cards:**
  - Structured white cards with 16px corners, featuring left-side vertical category color accents (Pink for homework/exams, Yellow for classes, Mint for free periods).
  - Internal information displays course title, classroom code, and dynamic time markers with clear typographic hierarchy.
- **Pill Chips & Filter Badges:**
  - Height: 32px, rounded-full.
  - Category backgrounds: `#FFD1DC`, `#C1F0DC`, `#FFF2B2` with darkened tone-matched text labels (`#851D34`, `#105436`, `#614E00`) ensuring WCAG AA contrast.
- **Input Field (Chat Bar):**
  - Continuous floating dock at bottom screen. White surface, pill boundary, containing micro-icon buttons for timetable import, voice dictation, and a solid navy circular send trigger.
- **Selection Controls (Checkboxes & Radios):**
  - Checkboxes use 6px rounded squares with navy check fills for completed homework tasks.
  - Radios feature navy pill rings with centered dot toggles for semester and term selection.