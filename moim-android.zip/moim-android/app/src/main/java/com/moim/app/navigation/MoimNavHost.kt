package com.moim.app.navigation

import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.moim.app.R
import com.moim.app.feature.auth.ui.StartScreen
import com.moim.app.feature.chat.ui.MainScreen
import com.moim.app.ui.component.MoimPrimaryButton
import com.moim.app.ui.component.PlaceholderScreen

/**
 * 화면 이동 지도.
 * 흐름: 시작 → 로그인 → 메인 / 시작 → 회원가입1 → 회원가입2 → 가입 완료 → 메인
 * 지금은 시작·메인만 실제 화면이고 나머지는 PlaceholderScreen(임시)이다.
 */
@Composable
fun MoimNavHost(
    modifier: Modifier = Modifier,
    navController: NavHostController = rememberNavController(),
) {
    NavHost(
        navController = navController,
        startDestination = MoimRoute.Start, // TODO: 자동 로그인 구현 후 로그인 상태면 Main으로
        modifier = modifier,
    ) {
        composable<MoimRoute.Start> {
            StartScreen(
                onLoginClick = { navController.navigate(MoimRoute.Login) },
                onSignUpClick = { navController.navigate(MoimRoute.SignUpBasic) },
            )
        }

        composable<MoimRoute.Login> {
            PlaceholderScreen(
                title = stringResource(R.string.screen_login),
                onBack = { navController.popBackStack() },
            ) {
                MoimPrimaryButton(
                    text = stringResource(R.string.debug_go_main),
                    onClick = { navController.navigateToMainClearingAuth() },
                )
            }
        }

        composable<MoimRoute.SignUpBasic> {
            PlaceholderScreen(
                title = stringResource(R.string.screen_signup_basic),
                onBack = { navController.popBackStack() },
            ) {
                MoimPrimaryButton(
                    text = stringResource(R.string.debug_go_signup_type),
                    onClick = { navController.navigate(MoimRoute.SignUpType) },
                )
            }
        }

        composable<MoimRoute.SignUpType> {
            PlaceholderScreen(
                title = stringResource(R.string.screen_signup_type),
                onBack = { navController.popBackStack() },
            ) {
                MoimPrimaryButton(
                    text = stringResource(R.string.debug_go_signup_done),
                    onClick = { navController.navigate(MoimRoute.SignUpDone) },
                )
            }
        }

        composable<MoimRoute.SignUpDone> {
            PlaceholderScreen(
                title = stringResource(R.string.screen_signup_done),
                onBack = null, // 가입 완료 후에는 뒤로 가기 없음
            ) {
                MoimPrimaryButton(
                    text = stringResource(R.string.debug_go_main),
                    onClick = { navController.navigateToMainClearingAuth() },
                )
            }
        }

        composable<MoimRoute.Main> {
            MainScreen(
                onCalendarClick = { navController.navigate(MoimRoute.Calendar) },
                onDmClick = { navController.navigate(MoimRoute.DmList) },
            )
        }

        composable<MoimRoute.Calendar> {
            PlaceholderScreen(
                title = stringResource(R.string.screen_calendar),
                onBack = { navController.popBackStack() },
            )
        }

        composable<MoimRoute.DmList> {
            PlaceholderScreen(
                title = stringResource(R.string.screen_dm_list),
                onBack = { navController.popBackStack() },
            )
        }

        composable<MoimRoute.Profile> {
            PlaceholderScreen(
                title = stringResource(R.string.screen_profile),
                onBack = { navController.popBackStack() },
            )
        }
    }
}

/** 로그인/가입이 끝나면 메인으로 가면서 인증 화면들을 뒤로 가기 기록에서 지운다. */
private fun NavHostController.navigateToMainClearingAuth() {
    navigate(MoimRoute.Main) {
        popUpTo(MoimRoute.Start) { inclusive = true }
        launchSingleTop = true
    }
}
