package com.moim.app.ui.theme

import androidx.compose.ui.graphics.Color

/** 일정 유형. DB의 schedules.type 값과 이름을 맞춘다. */
enum class ScheduleType { EXAM, ASSIGNMENT, APPOINTMENT, MEETUP, CLASS }

/** 모임 조율 화면에서 날짜/시간대별 가능 여부. */
enum class Availability { ALL, SOME, NONE, UNKNOWN }

/** 일정 유형 → 색 (캘린더 점, 카드 왼쪽 띠 등에 사용) */
fun ScheduleType.color(): Color = when (this) {
    ScheduleType.EXAM -> ScheduleExam
    ScheduleType.ASSIGNMENT -> ScheduleAssignment
    ScheduleType.APPOINTMENT -> ScheduleAppointment
    ScheduleType.MEETUP -> ScheduleMeetup
    ScheduleType.CLASS -> ScheduleClass
}

/** 가능 여부 → 색 */
fun Availability.color(): Color = when (this) {
    Availability.ALL -> AvailabilityAll
    Availability.SOME -> AvailabilitySome
    Availability.NONE -> AvailabilityNone
    Availability.UNKNOWN -> AvailabilityUnknown
}
