package com.moim.app.navigation

import kotlinx.serialization.Serializable

/*
 * 앱의 모든 화면 주소(route).
 * type-safe route: 문자열 대신 @Serializable 객체로 화면을 지정해서, 오타가 나면 컴파일 단계에서 잡힌다.
 * 화면에 값을 넘겨야 하면 data class로 만들면 된다. (예: data class DmRoom(val roomId: String))
 */
sealed interface MoimRoute {
    // 인증 흐름
    @Serializable data object Start : MoimRoute
    @Serializable data object Login : MoimRoute
    @Serializable data object SignUpBasic : MoimRoute
    @Serializable data object SignUpType : MoimRoute
    @Serializable data object SignUpDone : MoimRoute

    // 메인 흐름 (하단 탭바 없음: 메인 상단 앱바 아이콘으로만 이동)
    @Serializable data object Main : MoimRoute
    @Serializable data object Calendar : MoimRoute
    @Serializable data object DmList : MoimRoute
    @Serializable data object Profile : MoimRoute
}
