package com.moim.app.ui.theme

import androidx.compose.ui.graphics.Color

/*
 * moim 디자인 시스템 색상 (Stitch DESIGN.md 기준).
 * 화면 코드에서는 Color(0xFF...)를 직접 쓰지 말고 반드시 여기 값을 가져다 쓴다.
 */

// 브랜드 기본 색
val Navy = Color(0xFF0B2F7A)        // 버튼, 내 말풍선, 강조
val NavyDeep = Color(0xFF001B53)    // 로고 글자 등 가장 진한 남색
val SkyBlue = Color(0xFFDCEEFF)     // 배경 캔버스
val SkyBlueLight = Color(0xFFEDF5FF) // 시작 화면 그라데이션 중간색
val White = Color(0xFFFFFFFF)       // 카드, 눈송이 말풍선

// 글자 색
val TextPrimary = Color(0xFF191C21)
val TextSecondary = Color(0xFF444651)
val Outline = Color(0xFF747682)
val OutlineVariant = Color(0xFFC4C6D3)
val Secondary = Color(0xFF4F606E)
val Surface = Color(0xFFF8F9FF)
val ErrorRed = Color(0xFFBA1A1A)

// 보조 파스텔 (포인트 전용)
val PastelPink = Color(0xFFFFD1DC)
val PastelMint = Color(0xFFC1F0DC)
val PastelYellow = Color(0xFFFFF2B2)
val PastelPinkText = Color(0xFF851D34)
val PastelMintText = Color(0xFF105436)
val PastelYellowText = Color(0xFF614E00)

// 일정 유형 색: 시험 = 분홍/빨강, 과제 = 노랑, 개인 약속 = 파랑, 모임 = 초록, 수업 = 회색 계열
val ScheduleExam = Color(0xFFF06A8A)
val ScheduleAssignment = Color(0xFFF5C518)
val ScheduleAppointment = Color(0xFF4A7BE0)
val ScheduleMeetup = Color(0xFF3DBE8B)
val ScheduleClass = Color(0xFF9AA3B5)

// 모임 가능 여부 색: 초록 = 전원 가능 / 노랑 = 일부 가능 / 빨강 = 어려움 / 회색 = 정보 없음
val AvailabilityAll = Color(0xFF6FCF97)
val AvailabilitySome = Color(0xFFF7D774)
val AvailabilityNone = Color(0xFFEB7A7A)
val AvailabilityUnknown = Color(0xFFD8DAE1)
