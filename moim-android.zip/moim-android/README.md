# moim 안드로이드 앱 (1단계: 프로젝트 세팅)

## 여는 방법
1. 이 `moim-android` 폴더를 원하는 곳에 둔다 (예: moim 폴더 안)
2. Android Studio → **File > Open** → `moim-android` 폴더 선택
3. 오른쪽 아래 Gradle Sync가 끝날 때까지 기다린다 (처음엔 몇 분 걸림)
4. 위쪽 ▶ Run 버튼으로 에뮬레이터 실행 → 시작 화면이 뜨면 성공

## 1단계에서 만든 것
- Gradle 설정: 버전 카탈로그(`gradle/libs.versions.toml`), Compose, Hilt, Navigation(type-safe)
- 디자인 시스템: `ui/theme` (색, 글꼴 크기, 모서리, 간격)
- 공통 컴포넌트: `ui/component` (기본 버튼, 테두리 버튼, 임시 화면)
- 화면 이동 뼈대: `navigation` (시작 → 로그인/회원가입 → 메인 → 캘린더/DM)
- 실제 화면: 시작 화면, 메인 상단 앱바 (나머지는 임시 화면)
