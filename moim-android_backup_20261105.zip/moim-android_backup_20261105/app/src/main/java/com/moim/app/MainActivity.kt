package com.moim.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import com.moim.app.navigation.MoimNavHost
import com.moim.app.ui.theme.MoimTheme
import dagger.hilt.android.AndroidEntryPoint

/**
 * 앱의 유일한 Activity. 화면 전환은 전부 Compose 내비게이션이 처리한다.
 * @AndroidEntryPoint: 이 Activity 안에서 Hilt로 ViewModel 등을 주입받을 수 있게 해줌.
 */
@AndroidEntryPoint
class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        installSplashScreen() // super.onCreate 전에 호출해야 함
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()    // 상태바 영역까지 화면을 채움
        setContent {
            MoimTheme {
                MoimNavHost()
            }
        }
    }
}
