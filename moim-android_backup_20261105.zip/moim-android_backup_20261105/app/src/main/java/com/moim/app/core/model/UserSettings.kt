package com.moim.app.core.model

/*
 * 여러 기능(회원가입, 프로필, 캘린더)에서 같이 쓰는 사용자 설정 모델.
 * dbValue는 Supabase 테이블에 저장할 문자열 값이다.
 */

/** 항목별로 며칠 전에 알림을 받을지 (notification_prefs 테이블) */
data class NotificationPrefs(
    val examDaysBefore: Int,
    val assignmentDaysBefore: Int,
    val appointmentDaysBefore: Int,
)

/** 일정 성향 4종 (profiles.planning_type) */
enum class PlanningType(val dbValue: String, val defaultPrefs: NotificationPrefs) {
    EARLY("early", NotificationPrefs(examDaysBefore = 7, assignmentDaysBefore = 7, appointmentDaysBefore = 1)),
    THREE_DAY("three_day", NotificationPrefs(examDaysBefore = 3, assignmentDaysBefore = 3, appointmentDaysBefore = 1)),
    CRAMMING("cramming", NotificationPrefs(examDaysBefore = 1, assignmentDaysBefore = 1, appointmentDaysBefore = 1)),
    PLANNER("planner", NotificationPrefs(examDaysBefore = 3, assignmentDaysBefore = 3, appointmentDaysBefore = 7)),
}

/** 일정 공개 범위 (profiles.default_visibility, schedules.visibility) */
enum class Visibility(val dbValue: String) {
    PUBLIC("public"),
    FRIENDS("friends"),
    PRIVATE("private"),
}
