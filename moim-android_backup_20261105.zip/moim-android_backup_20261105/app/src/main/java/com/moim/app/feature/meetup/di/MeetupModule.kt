package com.moim.app.feature.meetup.di

import com.moim.app.feature.meetup.data.FakeMeetupExplainer
import com.moim.app.feature.meetup.data.FakeMeetupRepository
import com.moim.app.feature.meetup.domain.MeetupExplainer
import com.moim.app.feature.meetup.domain.MeetupRepository
import dagger.Binds
import dagger.Module
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent

@Module
@InstallIn(SingletonComponent::class)
abstract class MeetupModule {
    @Binds
    abstract fun bindMeetupRepository(impl: FakeMeetupRepository): MeetupRepository

    @Binds
    abstract fun bindMeetupExplainer(impl: FakeMeetupExplainer): MeetupExplainer
}
