package com.moim.app.core.data

import com.moim.app.core.model.Friend
import com.moim.app.core.model.Schedule
import kotlinx.coroutines.flow.Flow

/**
 * 친구 목록과 친구 일정.
 * 규칙: 친구의 "비공개" 일정은 제목·장소·유형 없이 시간만 내려온다.
 * (Supabase에서는 RLS + 가려진 뷰로 서버에서 막는다. 앱에서 가리는 게 아님)
 */
interface FriendRepository {
    fun observeFriends(): Flow<List<Friend>>

    /** 친구 일정 (비공개 일정은 이미 내용이 지워진 상태) */
    fun observeFriendSchedules(friendId: String): Flow<List<Schedule>>
}
