package com.moim.app.feature.meetup.data

import com.moim.app.core.data.FriendRepository
import com.moim.app.core.data.ScheduleRepository
import com.moim.app.core.model.Schedule
import com.moim.app.core.model.Visibility
import com.moim.app.feature.dm.domain.DmRepository
import com.moim.app.feature.meetup.domain.MeetupRepository
import com.moim.app.feature.meetup.domain.model.BusyBlock
import com.moim.app.feature.meetup.domain.model.MeetupMember
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import javax.inject.Inject

/**
 * 방 참여자 → 각자의 일정 → 바쁜 시간으로 바꾼다.
 * 나: 내 일정 전체 / 친구: 친구 일정 (비공개는 이미 내용이 지워져 옴)
 * TODO: Supabase에서는 서버 함수가 참여자들의 "바쁜 시간"만 내려주게 바꾸기
 */
class FakeMeetupRepository @Inject constructor(
    private val dmRepository: DmRepository,
    private val scheduleRepository: ScheduleRepository,
    private val friendRepository: FriendRepository,
) : MeetupRepository {

    @OptIn(ExperimentalCoroutinesApi::class)
    override fun observeMembers(roomId: String): Flow<List<MeetupMember>> =
        dmRepository.observeRoom(roomId).flatMapLatest { room ->
            if (room == null) return@flatMapLatest flowOf(emptyList())
            val flows = room.members.map { member ->
                val schedules = if (member.isMe) {
                    scheduleRepository.observeSchedules()
                } else {
                    friendRepository.observeFriendSchedules(member.id)
                }
                combine(schedules, flowOf(member)) { list, m ->
                    MeetupMember(id = m.id, name = m.name, isMe = m.isMe, busy = list.toBusyBlocks(m.isMe))
                }
            }
            combine(flows) { it.toList() }
        }

    /** 마감 일정(과제 23:59 등)은 시간을 차지하지 않으니 뺀다 */
    private fun List<Schedule>.toBusyBlocks(isMe: Boolean): List<BusyBlock> =
        filter { !it.isDeadline && !it.allDay && it.startAt.toLocalDate() == it.endAt.toLocalDate() }
            .map {
                val hidden = !isMe && it.visibility == Visibility.PRIVATE
                BusyBlock(
                    date = it.startAt.toLocalDate(),
                    start = it.startAt.toLocalTime(),
                    end = it.endAt.toLocalTime(),
                    label = if (hidden) null else it.title,
                )
            }
}
