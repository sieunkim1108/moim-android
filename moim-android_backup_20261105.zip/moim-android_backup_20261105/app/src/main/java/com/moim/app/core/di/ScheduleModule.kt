package com.moim.app.core.di

import com.moim.app.core.data.FakeFriendRepository
import com.moim.app.core.data.FakeScheduleRepository
import com.moim.app.core.data.FriendRepository
import com.moim.app.core.data.ScheduleRepository
import dagger.Binds
import dagger.Module
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

/** 일정·친구 저장소: 지금은 가짜(Fake) 구현을 넣어준다. Supabase 연결 시 여기만 바꾸면 됨 */
@Module
@InstallIn(SingletonComponent::class)
abstract class ScheduleModule {
    @Binds
    @Singleton
    abstract fun bindScheduleRepository(impl: FakeScheduleRepository): ScheduleRepository

    @Binds
    @Singleton
    abstract fun bindFriendRepository(impl: FakeFriendRepository): FriendRepository
}
