package com.moim.app

import android.app.Application
import dagger.hilt.android.HiltAndroidApp

/**
 * 앱 전체의 시작점.
 * @HiltAndroidApp 을 붙이면 Hilt가 앱 전체에서 쓸 의존성 그래프(객체 공장)를 만든다.
 */
@HiltAndroidApp
class MoimApplication : Application()
