package com.moim.app.feature.auth.domain.repository

import com.moim.app.feature.auth.domain.model.SignUpForm
import com.moim.app.feature.auth.domain.model.UserProfile
import kotlinx.coroutines.flow.StateFlow

/**
 * 인증 기능의 "약속(인터페이스)".
 * 화면과 UseCase는 이 인터페이스만 알고, 실제 구현은 Hilt가 넣어준다.
 * 지금은 FakeAuthRepository(메모리 목업), 다음 단계에서 Supabase 구현으로 바꾼다.
 */
interface AuthRepository {
    /** 지금 로그인한 사용자 (로그아웃 상태면 null) */
    val currentUser: StateFlow<UserProfile?>

    /** 학번을 쓸 수 있으면 true, 이미 가입돼 있으면 false */
    suspend fun isStudentIdAvailable(studentId: String): Result<Boolean>

    suspend fun signUp(form: SignUpForm): Result<UserProfile>

    suspend fun login(studentId: String, password: String): Result<UserProfile>
}
