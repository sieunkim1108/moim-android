package com.moim.app.feature.meetup.domain.usecase

import com.moim.app.core.data.ScheduleRepository
import com.moim.app.core.model.Schedule
import com.moim.app.core.model.ScheduleSource
import com.moim.app.core.model.ScheduleType
import com.moim.app.core.model.Visibility
import com.moim.app.feature.dm.domain.DmRepository
import com.moim.app.feature.dm.domain.model.RoomMessage
import com.moim.app.feature.meetup.domain.MeetupExplainer
import com.moim.app.feature.meetup.domain.MeetupRepository
import com.moim.app.feature.meetup.domain.MeetupScheduler
import com.moim.app.feature.meetup.domain.model.MeetupCandidate
import com.moim.app.feature.meetup.domain.model.MeetupMember
import kotlinx.coroutines.flow.Flow
import java.time.Clock
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import java.util.Locale
import java.util.UUID
import javax.inject.Inject

class ObserveMeetupMembersUseCase @Inject constructor(private val repository: MeetupRepository) {
    operator fun invoke(roomId: String): Flow<List<MeetupMember>> = repository.observeMembers(roomId)
}

/** 추천 시간 + 설명 한 쌍 */
data class ExplainedCandidate(val candidate: MeetupCandidate, val reason: String)

/** 앞으로 days일 중 추천 시간 3개를 고르고(알고리즘) 설명을 붙인다(AI) */
class RecommendMeetupUseCase @Inject constructor(
    private val explainer: MeetupExplainer,
    private val clock: Clock,
) {
    suspend operator fun invoke(
        members: List<MeetupMember>,
        durationMinutes: Long = DEFAULT_DURATION_MINUTES,
        days: Int = 14,
    ): List<ExplainedCandidate> {
        val now = LocalDateTime.now(clock)
        val dates = (0 until days).map { now.toLocalDate().plusDays(it.toLong()) }
        val candidates = MeetupScheduler.recommend(members, dates, durationMinutes, now)
        val reasons = runCatching { explainer.explain(candidates, members) }.getOrDefault(emptyList())
        return candidates.mapIndexed { i, c -> ExplainedCandidate(c, reasons.getOrElse(i) { "" }) }
    }

    companion object {
        const val DEFAULT_DURATION_MINUTES = 120L
    }
}

/**
 * [이 시간으로 모임 만들기]: 사용자가 직접 확정했을 때만 내 캘린더에 저장하고 방에 안내를 남긴다.
 */
class ConfirmMeetupUseCase @Inject constructor(
    private val scheduleRepository: ScheduleRepository,
    private val dmRepository: DmRepository,
    private val clock: Clock,
) {
    suspend operator fun invoke(roomId: String, roomTitle: String, candidate: MeetupCandidate): Result<Unit> {
        val schedule = Schedule(
            id = UUID.randomUUID().toString(),
            title = "$roomTitle 모임",
            type = ScheduleType.MEETUP,
            startAt = candidate.date.atTime(candidate.start),
            endAt = candidate.date.atTime(candidate.end),
            visibility = Visibility.FRIENDS,
            source = ScheduleSource.MEETUP,
            reminderDaysBefore = listOf(1),
        )
        return scheduleRepository.addSchedules(listOf(schedule)).onSuccess {
            val day = candidate.date.format(DateTimeFormatter.ofPattern("M월 d일 (E)", Locale.KOREAN))
            val time = DateTimeFormatter.ofPattern("a h시", Locale.KOREAN)
            val text = "📅 $day ${candidate.start.format(time)} ~ ${candidate.end.format(time)} 모임으로 정했어! 캘린더에 넣어 뒀어 💙"
            dmRepository.postBotMessages(roomId, listOf(RoomMessage.Bot(UUID.randomUUID().toString(), LocalDateTime.now(clock), text)))
        }
    }
}
