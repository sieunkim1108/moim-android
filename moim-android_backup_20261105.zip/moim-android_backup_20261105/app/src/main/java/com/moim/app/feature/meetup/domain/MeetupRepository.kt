package com.moim.app.feature.meetup.domain

import com.moim.app.feature.meetup.domain.model.MeetupCandidate
import com.moim.app.feature.meetup.domain.model.MeetupMember
import kotlinx.coroutines.flow.Flow

/** 채팅방 참여자들의 바쁜 시간 (친구 비공개 일정은 내용 없이 시간만) */
interface MeetupRepository {
    fun observeMembers(roomId: String): Flow<List<MeetupMember>>
}

/**
 * 추천 시간마다 한 줄 설명을 붙여 준다.
 * 규칙: 점수·순위는 MeetupScheduler(코드)가 정하고, 여기(AI)는 설명만 한다.
 * TODO: 서버의 Claude API로 교체 (API 키는 서버 환경변수에만)
 */
interface MeetupExplainer {
    suspend fun explain(candidates: List<MeetupCandidate>, members: List<MeetupMember>): List<String>
}
