package com.moim.app.feature.auth.domain

/**
 * 회원가입 입력값 검사 규칙. 안드로이드에 의존하지 않는 순수 함수라 단위 테스트하기 쉽다.
 */
object SignUpValidator {
    private val studentIdRegex = Regex("^\\d{7}$")

    /** 학번: 숫자 7자리 */
    fun isValidStudentId(studentId: String): Boolean = studentIdRegex.matches(studentId)

    /** 비밀번호: 8자 이상, 영문과 숫자를 각각 하나 이상 포함 */
    fun isValidPassword(password: String): Boolean =
        password.length >= 8 &&
            password.any { it.isLetter() && it.code < 128 } &&
            password.any { it.isDigit() }

    fun isValidName(name: String): Boolean = name.isNotBlank()
}
