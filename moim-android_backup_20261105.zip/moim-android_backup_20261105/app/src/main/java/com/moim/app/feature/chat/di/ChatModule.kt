package com.moim.app.feature.chat.di

import com.moim.app.feature.chat.data.FakeChatBotRepository
import com.moim.app.feature.chat.domain.ChatBotRepository
import dagger.Binds
import dagger.Module
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

/** 눈송이 구현 선택: 지금은 규칙 기반 목업 */
@Module
@InstallIn(SingletonComponent::class)
abstract class ChatModule {
    @Binds
    @Singleton
    abstract fun bindChatBotRepository(impl: FakeChatBotRepository): ChatBotRepository
}
