package com.moim.app.feature.auth.domain.model

import com.moim.app.core.model.NotificationPrefs
import com.moim.app.core.model.PlanningType
import com.moim.app.core.model.Visibility
import java.time.LocalDate

/** 회원가입 때 서버로 보낼 정보 전체 */
data class SignUpForm(
    val studentId: String,
    val name: String,
    val birthDate: LocalDate,
    val college: String,
    val major: String,
    val password: String,
    val planningType: PlanningType,
    val notificationPrefs: NotificationPrefs,
    val defaultVisibility: Visibility,
)

/** 로그인한 사용자 정보 (profiles 테이블 한 줄) */
data class UserProfile(
    val id: String,
    val studentId: String,
    val name: String,
    val college: String,
    val major: String,
    val planningType: PlanningType,
    val defaultVisibility: Visibility,
)

/** 인증 과정에서 생길 수 있는 실패. 화면에서는 종류별로 다른 문구를 보여준다. */
sealed class AuthException : Exception() {
    data object InvalidCredentials : AuthException()
    data object DuplicateStudentId : AuthException()
    data object Network : AuthException()
}
