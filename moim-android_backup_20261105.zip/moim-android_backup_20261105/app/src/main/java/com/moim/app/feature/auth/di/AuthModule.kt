package com.moim.app.feature.auth.di

import com.moim.app.feature.auth.data.FakeAuthRepository
import com.moim.app.feature.auth.domain.repository.AuthRepository
import dagger.Binds
import dagger.Module
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

/**
 * Hilt 모듈: "AuthRepository가 필요하면 FakeAuthRepository를 넣어줘"라고 알려주는 곳.
 * Supabase 구현이 생기면 여기 한 줄만 바꾸면 앱 전체가 새 구현을 쓴다.
 */
@Module
@InstallIn(SingletonComponent::class)
abstract class AuthModule {

    @Binds
    @Singleton
    abstract fun bindAuthRepository(impl: FakeAuthRepository): AuthRepository
}
