package com.moim.app.core.model

/** 친구 한 명 (friendships로 연결된 profiles 한 줄의 공개 정보) */
data class Friend(
    val id: String,
    val name: String,
    val major: String? = null, // 채팅 목록에 "소프트웨어학부"처럼 표시
)

/** 이름에서 "성"을 뺀 부르는 이름 (예: 김시은 → 시은). 두 글자 이하는 그대로. */
val Friend.givenName: String get() = if (name.length >= 3) name.drop(1) else name
