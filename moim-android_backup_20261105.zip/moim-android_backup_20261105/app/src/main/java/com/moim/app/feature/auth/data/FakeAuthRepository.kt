package com.moim.app.feature.auth.data

import com.moim.app.core.model.PlanningType
import com.moim.app.core.model.Visibility
import com.moim.app.feature.auth.domain.model.AuthException
import com.moim.app.feature.auth.domain.model.SignUpForm
import com.moim.app.feature.auth.domain.model.UserProfile
import com.moim.app.feature.auth.domain.repository.AuthRepository
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import java.util.UUID
import javax.inject.Inject
import javax.inject.Singleton

/**
 * 서버 없이 화면 흐름을 확인하기 위한 목업 저장소. 앱을 끄면 데이터가 사라진다.
 * 테스트 계정: 학번 1234567 / 비밀번호 moim1234
 * TODO: Supabase 연결 단계에서 SupabaseAuthRepository로 교체 (AuthModule의 @Binds 한 줄만 바꾸면 됨)
 */
@Singleton
class FakeAuthRepository @Inject constructor() : AuthRepository {

    private data class Account(val password: String, val profile: UserProfile)

    private val _currentUser = MutableStateFlow<UserProfile?>(null)
    override val currentUser: StateFlow<UserProfile?> = _currentUser.asStateFlow()

    private val mutex = Mutex()
    private val accounts = mutableMapOf(
        DEMO_STUDENT_ID to Account(
            password = DEMO_PASSWORD,
            profile = UserProfile(
                id = UUID.randomUUID().toString(),
                studentId = DEMO_STUDENT_ID,
                name = "김눈송",
                college = "소프트웨어학부",
                major = "컴퓨터과학전공",
                planningType = PlanningType.EARLY,
                defaultVisibility = Visibility.FRIENDS,
            ),
        ),
    )

    override suspend fun isStudentIdAvailable(studentId: String): Result<Boolean> {
        delay(FAKE_DELAY_MS) // 네트워크 흉내
        return mutex.withLock { Result.success(studentId !in accounts) }
    }

    override suspend fun signUp(form: SignUpForm): Result<UserProfile> {
        delay(FAKE_DELAY_MS)
        return mutex.withLock {
            if (form.studentId in accounts) {
                Result.failure(AuthException.DuplicateStudentId)
            } else {
                val profile = UserProfile(
                    id = UUID.randomUUID().toString(),
                    studentId = form.studentId,
                    name = form.name,
                    college = form.college,
                    major = form.major,
                    planningType = form.planningType,
                    defaultVisibility = form.defaultVisibility,
                )
                accounts[form.studentId] = Account(form.password, profile)
                _currentUser.value = profile // 가입하면 바로 로그인 상태
                Result.success(profile)
            }
        }
    }

    override suspend fun login(studentId: String, password: String): Result<UserProfile> {
        delay(FAKE_DELAY_MS)
        return mutex.withLock {
            val account = accounts[studentId]
            if (account != null && account.password == password) {
                _currentUser.value = account.profile
                Result.success(account.profile)
            } else {
                Result.failure(AuthException.InvalidCredentials)
            }
        }
    }

    private companion object {
        const val DEMO_STUDENT_ID = "1234567"
        const val DEMO_PASSWORD = "moim1234"
        const val FAKE_DELAY_MS = 600L
    }
}
