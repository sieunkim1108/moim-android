package com.moim.app.feature.meetup.ui

import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.navigation.toRoute
import com.moim.app.core.model.Availability
import com.moim.app.feature.calendar.domain.CalendarMath
import com.moim.app.feature.dm.domain.model.ChatRoom
import com.moim.app.feature.dm.domain.usecase.ObserveRoomUseCase
import com.moim.app.feature.meetup.domain.MeetupScheduler
import com.moim.app.feature.meetup.domain.model.MeetupMember
import com.moim.app.feature.meetup.domain.model.TimeRange
import com.moim.app.feature.meetup.domain.usecase.ConfirmMeetupUseCase
import com.moim.app.feature.meetup.domain.usecase.ExplainedCandidate
import com.moim.app.feature.meetup.domain.usecase.ObserveMeetupMembersUseCase
import com.moim.app.feature.meetup.domain.usecase.RecommendMeetupUseCase
import com.moim.app.navigation.MoimRoute
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.launchIn
import kotlinx.coroutines.flow.onEach
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.time.Clock
import java.time.LocalDate
import java.time.YearMonth
import javax.inject.Inject

enum class MeetupMessage { CONFIRM_FAILED }

data class MeetupUiState(
    val today: LocalDate,
    val room: ChatRoom? = null,
    val members: List<MeetupMember> = emptyList(),
    val visibleMonth: YearMonth,
    val selectedDate: LocalDate,
    val availability: Map<LocalDate, Availability> = emptyMap(),
    val recommendations: List<ExplainedCandidate>? = null, // null = 계산 중
    val selectedRecommendation: Int = 0,
    val isConfirming: Boolean = false,
    val confirmed: Boolean = false, // true면 화면이 채팅방으로 돌아간다
    val message: MeetupMessage? = null,
) {
    /** 선택한 날 전원이 비는 시간대 */
    val commonFree: List<TimeRange> get() = MeetupScheduler.commonFreeRanges(members, selectedDate)

    /** 선택한 날 2시간 기준 최대 가능 인원 */
    val bestCountOnSelected: Int
        get() = MeetupScheduler.bestSlotOn(members, selectedDate, RecommendMeetupUseCase.DEFAULT_DURATION_MINUTES)
            ?.availableCount ?: 0

    val availabilityCounts: Map<Availability, Int> get() = availability.values.groupingBy { it }.eachCount()
}

private data class MeetupLocal(
    val visibleMonth: YearMonth,
    val selectedDate: LocalDate,
    val dateChosenByUser: Boolean = false,
    val recommendations: List<ExplainedCandidate>? = null,
    val selectedRecommendation: Int = 0,
    val isConfirming: Boolean = false,
    val confirmed: Boolean = false,
    val message: MeetupMessage? = null,
)

@HiltViewModel
class MeetupViewModel @Inject constructor(
    savedStateHandle: SavedStateHandle,
    observeRoom: ObserveRoomUseCase,
    observeMembers: ObserveMeetupMembersUseCase,
    private val recommend: RecommendMeetupUseCase,
    private val confirmMeetup: ConfirmMeetupUseCase,
    clock: Clock,
) : ViewModel() {

    private val roomId = savedStateHandle.toRoute<MoimRoute.Meetup>().roomId
    private val today = LocalDate.now(clock)
    private val local = MutableStateFlow(MeetupLocal(YearMonth.from(today), today))
    private val members = observeMembers(roomId).distinctUntilChanged()

    val uiState: StateFlow<MeetupUiState> = combine(observeRoom(roomId), members, local) { room, m, l ->
        MeetupUiState(
            today = today,
            room = room,
            members = m,
            visibleMonth = l.visibleMonth,
            selectedDate = l.selectedDate,
            availability = CalendarMath.monthGrid(l.visibleMonth).associateWith { date ->
                MeetupScheduler.dayAvailability(m, date, RecommendMeetupUseCase.DEFAULT_DURATION_MINUTES, today)
            },
            recommendations = l.recommendations,
            selectedRecommendation = l.selectedRecommendation,
            isConfirming = l.isConfirming,
            confirmed = l.confirmed,
            message = l.message,
        )
    }.stateIn(
        viewModelScope,
        SharingStarted.WhileSubscribed(5_000),
        MeetupUiState(today = today, visibleMonth = YearMonth.from(today), selectedDate = today),
    )

    init {
        // 추천 시간: 알고리즘이 고르고 AI가 설명. 처음엔 1순위 날짜를 달력에서 선택해 둔다.
        members.onEach { m ->
            val result = recommend(m)
            local.update { l ->
                val first = result.firstOrNull()?.candidate?.date
                if (!l.dateChosenByUser && first != null) {
                    l.copy(recommendations = result, selectedRecommendation = 0, selectedDate = first, visibleMonth = YearMonth.from(first))
                } else {
                    l.copy(recommendations = result, selectedRecommendation = 0)
                }
            }
        }.launchIn(viewModelScope)
    }

    fun onDateSelect(date: LocalDate) = local.update {
        it.copy(selectedDate = date, visibleMonth = YearMonth.from(date), dateChosenByUser = true)
    }

    fun onPrevMonth() = local.update { it.copy(visibleMonth = it.visibleMonth.minusMonths(1)) }

    fun onNextMonth() = local.update { it.copy(visibleMonth = it.visibleMonth.plusMonths(1)) }

    /** 추천을 고르면 달력·타임라인도 그 날짜로 이동 */
    fun onRecommendationSelect(index: Int) = local.update { l ->
        val date = l.recommendations?.getOrNull(index)?.candidate?.date ?: return@update l
        l.copy(selectedRecommendation = index, selectedDate = date, visibleMonth = YearMonth.from(date), dateChosenByUser = true)
    }

    /** [이 시간으로 모임 만들기] — 사용자가 눌렀을 때만 캘린더에 저장 */
    fun onConfirm() {
        val state = uiState.value
        val room = state.room ?: return
        val pick = state.recommendations?.getOrNull(state.selectedRecommendation)?.candidate ?: return
        if (state.isConfirming) return
        local.update { it.copy(isConfirming = true) }
        viewModelScope.launch {
            confirmMeetup(room.id, room.title, pick)
                .onSuccess { local.update { it.copy(isConfirming = false, confirmed = true) } }
                .onFailure { local.update { it.copy(isConfirming = false, message = MeetupMessage.CONFIRM_FAILED) } }
        }
    }

    fun onNavigatedBack() = local.update { it.copy(confirmed = false) }

    fun onMessageShown() = local.update { it.copy(message = null) }
}
