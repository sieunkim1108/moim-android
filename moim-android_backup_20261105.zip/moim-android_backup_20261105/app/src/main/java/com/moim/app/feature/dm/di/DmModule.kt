package com.moim.app.feature.dm.di

import com.moim.app.feature.dm.data.FakeDmRepository
import com.moim.app.feature.dm.domain.DmRepository
import dagger.Binds
import dagger.Module
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
abstract class DmModule {
    @Binds
    @Singleton
    abstract fun bindDmRepository(impl: FakeDmRepository): DmRepository
}
